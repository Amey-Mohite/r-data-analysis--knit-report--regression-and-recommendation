1. Data folder containing all the csv files.
2. Figs folder containing the all the plots 
3. Images folder  containing reference images
4. Code.html file is knitr report in html format
5. Code.Rmd is the .Rmd file.
